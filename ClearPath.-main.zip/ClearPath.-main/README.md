Function:
Give teens a safe space to fight their addictions!
Sobriety tracker, mood, journal, etc.
